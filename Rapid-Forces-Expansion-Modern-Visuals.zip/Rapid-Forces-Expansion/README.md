# Rapid Forces Expansion — Unciv Android

An extension mod for the standard Unciv ruleset. Adds seven fast-moving units available to every civilization.

## Added units

| Unit | Movement | Unlock |
|---|---:|---|
| Rapid Cavalry | 6 | Horseback Riding |
| Mobile Recon Vehicle | 5 | Combustion |
| Rapid Response Infantry | 3 | Replaceable Parts |
| Fast Armor Vehicle | 6 | Combustion |
| Rapid Air Patrol | 8 | Radar |
| Fast Patrol Ship | 7 | Combustion |
| Rapid Missile Corvette | 6 | Electronics |

The units are balanced as game pieces and use existing Unciv unit types and technology names. They do not replace any standard units.

## Install on Android

1. Extract the ZIP file.
2. Copy the `Rapid-Forces-Expansion` folder into Unciv's `mods` folder.
3. Open Unciv → Mods and enable **Rapid Forces Expansion**.
4. Start a new game with the standard ruleset and the extension enabled.

## Compatibility note

The JSON files are syntactically validated and use documented Unciv unit fields. They have not yet been tested inside the exact Unciv version installed on your device. If the in-game mod error checker flags a technology or unique, send me the error text or screenshot and I can correct it.


## Modern unit visuals
The seven unit icon images have been refreshed with modern military vehicle, infantry, aircraft, and naval artwork, framed for readability in the Unciv unit interface.
